# The FPM namespace
module FPM
  class Package; end
end
