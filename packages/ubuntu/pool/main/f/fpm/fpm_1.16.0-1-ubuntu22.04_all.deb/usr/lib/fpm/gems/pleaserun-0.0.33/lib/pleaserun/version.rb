module PleaseRun
  VERSION = "0.0.33"
end
