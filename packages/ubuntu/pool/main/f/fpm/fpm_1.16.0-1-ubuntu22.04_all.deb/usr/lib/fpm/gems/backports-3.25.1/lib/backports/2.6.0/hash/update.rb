require 'backports/2.6.0/hash/merge'
