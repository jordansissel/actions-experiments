require 'backports/tools/make_block_optional'

Backports.make_block_optional Array, :collect!, :test_on => [42]
