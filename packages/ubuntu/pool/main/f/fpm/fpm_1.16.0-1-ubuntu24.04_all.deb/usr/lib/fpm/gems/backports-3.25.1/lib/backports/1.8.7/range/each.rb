require 'backports/tools/make_block_optional'

Backports.make_block_optional Range, :each, :test_on => 69..666
