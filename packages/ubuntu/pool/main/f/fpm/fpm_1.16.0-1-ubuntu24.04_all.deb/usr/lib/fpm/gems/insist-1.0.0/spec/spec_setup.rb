$: << File.join(File.dirname(File.dirname(__FILE__)), "lib")
