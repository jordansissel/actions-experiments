require "fpm/namespace"

# Raised if a package is configured in an unsupported way
class FPM::InvalidPackageConfiguration < StandardError; end
