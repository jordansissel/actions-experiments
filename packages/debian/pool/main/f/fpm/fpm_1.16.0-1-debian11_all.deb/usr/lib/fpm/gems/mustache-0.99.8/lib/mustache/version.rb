class Mustache
  Version = VERSION = '0.99.8'
end
