require 'backports/tools/require_relative_dir'

Backports.require_relative_dir
